#pragma once
#include <string>

void runClient(std::string hostName, int PORT, float time);